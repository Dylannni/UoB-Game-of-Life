# CSA Coursework: Game of Life skeleton (Go)

All documentation is available [here](https://uob-csa.github.io/gol-docs/)
